package My::Formatter;
use Kwiki::Formatter '-Base';
