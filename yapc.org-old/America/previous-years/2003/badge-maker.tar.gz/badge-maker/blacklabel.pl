#!/usr/bin/perl -w 

use Imager qw(:handy);

# Activate Logging
Imager::init_log("font.log", 1);


# set base parameters

$fontname_tt="./fonts/verdanab.ttf";
$lf=40;    # large font
$sf=27;    # small font
$ys=$xs=1; # shadow shift

$xmul=2;   # x-tiling of images
$ymul=3;   # y-tiling of images

$exheight=50;
$exwidth=1;

$regmark=20;

#$outtype="png";
$outtype="ppm";

# Load base image 

$base=Imager->new();
$base->read(file=>"base6c.png");
$bw=$base->getwidth();
$bh=$base->getheight();

print "width=$bw\n";
print "height=$bh\n";

my $blue=Imager::Color->new(44,34,152,255);
die $Imager::ERRSTR unless $blue;
#my $hue=Imager::Color->new(129, 45, 65 ,255);
my $hue=Imager::Color->new(160, 40, 40 ,255);
die $Imager::ERRSTR unless $hue;
my $black=Imager::Color->new(100, 100, 100, 255);
die $Imager::ERRSTR unless $black;
my $white=Imager::Color->new(255, 255, 255, 255);
die $Imager::ERRSTR unless $white;

my $font=NF(file=>$fontname_tt,size=>$lf) or die $base->{ERRSTR};

$page=Imager->new(xsize=>$bw*$xmul+$exwidth ,ysize=>$bh*$ymul+$exheight) or die "Cannot allocate page image".$Imager::ERRSTR;
$page->box(color=>$white, filled=>1);



# dummy data generation 

$istr1="Arnar M. Hrafnkelsson";
$istr2="addi\@umich.edu (Addi)";

@string1=map { $istr1.$_ } 1..10;
@string2=map { $istr2.$_ } 1..10;

# ok all data is set up - lets rock!

$n=0;
$m=0;
$pagenum=0;
$eject=0;

for $i (0..$#string1) {
  print "Doing tile ($m,$n)\n";
  $left=$m*$bw;
  $top=$n*$bh;

  my $string1=$string1[$i];
  my $string2=$string2[$i];

  $page->paste(left=>$left , top=>$top, img=>$base);

  shadow_text_center($page, $font, $lf, $string1, $left, $top+310,$hue);
  shadow_text_center($page, $font, $sf, $string2, $left, $top+350,$blue);

  $eject=0;
  $m++;
  if ($m>$xmul-1) {
    $n++;
    $m=0;
  }

  if ($n>$ymul-1) {
    registrate($page,$pagenum);
    $page->write(file=>"output/page$pagenum.$outtype");
    $eject=1;
    $pagenum++;
    $n=0;
    $m=0;
    $page->box(color=>$white, filled=>1);
    print "ejecting page $pagenum\n";
  }
 

}

# partial endpage 
if (!$eject) {
  registrate($page,$pagenum);
  $page->write(file=>"output/page$pagenum.$outtype");
  print "ejecting page $pagenum\n";
} 






# put registration marks on image and page number - uses some globals

sub registrate {
  my ($img,$pagenum)=@_;

  for my $ys(0..$ymul+1) {
    $img->line(x1=>0, x2=>$regmark, y1=>$bh*$ys, y2=>$bh*$ys,color=>$black);
    $img->line(x1=>$img->getwidth()-$regmark, x2=>$img->getwidth(), y1=>$bh*$ys, y2=>$bh*$ys,color=>$black);
  }

  for my $xs(0..$xmul+1) {
    $img->line(y1=>0, y2=>$regmark, x1=>$bw*$xs, x2=>$bw*$xs,color=>$black);
    $img->line(y1=>$img->getheight()-$regmark, y2=>$img->getheight(), x1=>$bw*$xs, x2=>$bw*$xs,color=>$black);
  }


	$page->string(font=>$font, color=>$blue , size=>$exheight/2, string=>"page $pagenum", 'x'=>10, 'y'=>$page->getheight-$exheight/3)
		or die $page->{ERRSTR};

	$page->filter(type=>'contrast',intensity=>1.1);
}



# font, size, string, xofset, y coord
# uses some globals (Yes I'm in a hurry)

sub shadow_text_center {
  my ($img, $font, $size, $string, $xofs, $y, $color) = @_;

#  print "xofs=$xofs y=$y\n";

  my @bbox=$font->bounding_box(string=>$string,size=>$size);
#  print "bbox= @bbox\n";
  my $textwidth=$bbox[2]-$bbox[0];
  my $xc=$bw/2-$textwidth/2+$bbox[0];

  $img->string(font=>$font, color=>$black, size=> $size, text=>$string, 'x'=>$xofs+$xc+$xs, 'y'=>$y+$ys) or die $base->{ERRSTR};
  $img->string(font=>$font, color=>$color , size=> $size, text=>$string, 'x'=>$xofs+$xc,     'y'=>$y)     or die $base->{ERRSTR};

}

