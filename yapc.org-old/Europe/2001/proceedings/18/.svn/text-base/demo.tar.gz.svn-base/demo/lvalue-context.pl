use Inline C => <<NOMO;

U8 wantlvalue ()
{
    return cxstack[cxstack_ix].blk_sub.lval;
}

NOMO

sub foo :lvalue {
    print (wantlvalue() ? "lvaluably\n" : "rvaluably\n");
    my $foo
}

foo();
foo() = 23;