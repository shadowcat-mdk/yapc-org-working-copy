CHECK {
    while (my($n,$v) = each %::) {
        $$v = 0 if !defined $$v;
    }
}

print "It worked!\n" if defined($any_variable)
                     && $any_variable == 0;