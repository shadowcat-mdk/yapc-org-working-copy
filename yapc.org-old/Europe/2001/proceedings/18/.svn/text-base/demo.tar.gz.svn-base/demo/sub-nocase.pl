sub AUTOLOAD {
	no strict 'refs';
	goto &{lc $AUTOLOAD};
}

sub foo {
	print "It worked!\n";
}

FoO();
