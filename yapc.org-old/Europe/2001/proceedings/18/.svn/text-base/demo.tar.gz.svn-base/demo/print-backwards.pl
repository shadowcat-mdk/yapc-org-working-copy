sub TIEHANDLE {my $x; bless \$x}
sub PRINT {
    shift;
    print REALOUT map scalar reverse, reverse @_;
}
open(REALOUT, ">&STDOUT");
tie *STDOUT, "main";
print "\n!dekrow", " tI"