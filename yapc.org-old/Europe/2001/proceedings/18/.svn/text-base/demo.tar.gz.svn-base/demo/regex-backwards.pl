use overload;
BEGIN {

    overload::constant qr => sub {
	return reverse shift();
    };

}

print "It worked!\n" if "foo" =~ /oof^/;