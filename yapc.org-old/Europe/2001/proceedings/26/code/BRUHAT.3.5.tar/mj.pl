END{$00=~s/(.*)(\n)/(++$*%(@ARGV?1:2)?reverse$1:$1).$2/ge;eval$00}$00=<<'OPC 5'
 "-|=I+X#.";($W,$H,$w,$h,$z,$n,$i)=(79,23,2,2,1,25,1);'esrever lave;".#X+I=|-" 
';while(@ARGV){${pop@ARGV}=pop}do{while(/([a-z])\s*([-\d.]*)/cgi){${$1}=$2if$1}
;#%)":^//@]n\n$<:%z$<*%a$<^%A$<_}y$<=%x$<!%h$<|%w$<[%j$<(%H$<;%W$<'#qq=_$;_$=e$
@c=split//,$00;for(1..$i){$w*=$z;$h*=$z;$A+=$a;for(0..$H*$W-1){($U,$R,@0)=(f($_
%$W,int$_/$W),$n);($p,$q)=($j?($x,$y):(#(:)y$,x$(?j$(=)q$,p$(;)n$,)W$/_$tni,W$%
$U,$R));do{($U,$R)=($U*$U-$R*$R+$p,$U*2*$R+$q)}until(($U*$U+$R*$R>4)||--$0[0]==
0);print$c[int($0[0]*9/$n)],++$_%$W?$# : #$?W$%_$++,])n$/9*]0[0$(tni[c$tnirp;)0
"\n"}};sub f{($w/$W*($_[0]-($W-1)/2)*cos($A)+$h/$H*(($H-1)/2-$_[1])*sin($A)+$x,
($_[0]-($W-1)/2)*-$w/$W*sin($A)+$h/$H*(#(*H$/h$+)A$(nis*W$/w$-*)2/)1-W$(-]0[_$(
($H-1)/2-$_[1])*cos($A)+$y)};exit if$e=~/q/;BEGIN{push@ARGV,split' ',$ENV{TPJ}}
}#)><(elihw}tnirp;"ujd:zhoCawHmn =WxAy"{("\)*|@]^[;/:%<'!_="y;/%Y$<Y%X$<X%/}/s;
OPC 5
